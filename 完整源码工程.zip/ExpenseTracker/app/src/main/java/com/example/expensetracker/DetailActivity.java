package com.example.expensetracker;

import static com.example.expensetracker.MainActivity.recordList;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    private TextView tvDetail;
    private ListView lvRecords;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // 绑定控件
        tvDetail = findViewById(R.id.tv_detail);
        lvRecords = findViewById(R.id.lv_records);
        btnBack = findViewById(R.id.btn_back);

        // 接收从上一个页面传递过来的数据
        Intent intent = getIntent();
        String amount = intent.getStringExtra("amount");
        String note = intent.getStringExtra("note");
        String type = intent.getStringExtra("type");
        String category = intent.getStringExtra("category");
        String important = intent.getStringExtra("important");

        // 显示本次记录详情
        String detailText = "【本次记录】\n"
                + "金额：" + amount + " 元\n"
                + "类型：" + type + "\n"
                + "分类：" + category + "\n"
                + "备注：" + note + "\n"
                + "是否重要：" + important;
        tvDetail.setText(detailText);

        // 使用 MainActivity 中的静态列表（只显示真实添加过的记录）
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                MainActivity.recordList
        );
        lvRecords.setAdapter(adapter);

        // 返回按钮
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // 关闭当前页面，返回主页面
            }
        });
    }
}