package com.example.expensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etAmount, etNote;
    private RadioGroup rgType;
    private Spinner spinnerCategory;
    private CheckBox cbImportant;
    private Button btnSubmit;

    // 用于在应用运行期间保存所有记账记录
    public static List<String> recordList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. 绑定控件
        etAmount = findViewById(R.id.et_amount);
        etNote = findViewById(R.id.et_note);
        rgType = findViewById(R.id.rg_type);
        spinnerCategory = findViewById(R.id.spinner_category);
        cbImportant = findViewById(R.id.cb_important);
        btnSubmit = findViewById(R.id.btn_submit);

        // 2. 为 Spinner 设置数据源
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.category_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        // 3. 按钮点击事件
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 获取金额
                String amountStr = etAmount.getText().toString().trim();
                if (amountStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "请输入金额", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 获取备注
                String note = etNote.getText().toString().trim();
                if (note.isEmpty()) {
                    note = "无备注";
                }

                // 获取类型（收入/支出）
                int checkedId = rgType.getCheckedRadioButtonId();
                RadioButton selectedRb = findViewById(checkedId);
                String type = selectedRb.getText().toString();

                // 获取分类
                String category = spinnerCategory.getSelectedItem().toString();

                // 获取是否重要
                boolean isImportant = cbImportant.isChecked();
                String importantStr = isImportant ? "是" : "否";

                // 生成当前记录字符串并加入静态列表（最新的放在最前面）
                String currentRecord = type + " | " + category + " | " + amountStr + "元 | " + note + " | 重要：" + importantStr;
                recordList.add(0, currentRecord);  // 插入到列表最前面

                // 创建 Intent 并传递数据（用于详情展示）
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("amount", amountStr);
                intent.putExtra("note", note);
                intent.putExtra("type", type);
                intent.putExtra("category", category);
                intent.putExtra("important", importantStr);

                // 启动第二个 Activity
                startActivity(intent);

                // 提交后清空输入框
                etAmount.setText("");
                etNote.setText("");
                cbImportant.setChecked(false);
            }
        });
    }
}